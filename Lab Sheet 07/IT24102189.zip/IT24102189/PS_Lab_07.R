setwd("C:/Users/Anonymous/Desktop/IT24102189")

#01
punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)

#02
pexp(2, rate=1/3,lower.tail = TRUE)

#03
#1
1 - pnorm(130, mean=100, sd=15, lower.tail = TRUE)
#2
qnorm(0.95, mean=100, sd=15, lower.tail = TRUE)
